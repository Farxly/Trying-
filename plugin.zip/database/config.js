module.exports = {
  tokens: "TOKENMAKLU",  // Masukin Bot token kamu
  owners: "ID", // Masukin ID Telegram kamu
  port: "9999", // Masukin Port panel kamu 
  ipvps: "IPVS"
};