
const chalk = require('chalk');

const startServer = require('./index.js');